CKEDITOR.plugins.setLang('attachment', 'ru',
{
  attachment : 
  {
    title : "Включить вложения",
    url: "URL",
    name: "Название",
    button : "Вставить"
  }
});
